import { Component } from '@angular/core';

@Component({
  selector: 'sn-about',
  template: './about.component.html',
  styleUrls: ['./about.component.html']
})

export class AboutComponent { };
